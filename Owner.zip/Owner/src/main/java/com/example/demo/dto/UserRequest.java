package com.example.demo.dto;
/*Author: Sanket Nadargi*/

public class UserRequest {
	// Defines the UserRequest class, which is a DTO for encapsulating the status of a user.

	private Boolean active;

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}
	

}