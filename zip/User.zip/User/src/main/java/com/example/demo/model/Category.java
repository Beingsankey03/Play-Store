package com.example.demo.model;
/*Author: Sanket Nadargi*/

public enum Category {
	
	GAMES,
	BEAUTY,
	FASHION,
	WOMENS_HEALTH

}
